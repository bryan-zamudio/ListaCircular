package listaCircular;
public class PosicionIlegalException extends Exception {
    public PosicionIlegalException(){
        super("posición ilegal en la lista");
    }
}
